const DB = require('../database/models');



const homeCont = {
   index: function (req, res) {
    res.render('Home', );
},

    busqueda: function (req, res) {
        res.render('pagina4');
},




};

module.exports = homeCont;  